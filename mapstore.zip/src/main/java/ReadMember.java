import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import data.Person;

public class ReadMember {

    public static void main(String[] args) {
        HazelcastInstance hz = Hazelcast.newHazelcastInstance();
        IMap<Long, Person> personMap = hz.getMap("personMap");
        Person p = personMap.get(4L);
        System.out.println("personMap:" + p);
        //personMap.put(8L, new Person(8L, "Peter_8"));
//        
//        IMap<Long, Person> testMap = hz.getMap("testMap");
//        System.out.println("testMap:" + testMap.get(1L));        
//        
        //hz.shutdown();
    }
}
