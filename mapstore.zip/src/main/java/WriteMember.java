import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
import data.Person;

public class WriteMember {

    public static void main(String[] args) {
        HazelcastInstance hz = Hazelcast.newHazelcastInstance();
        IMap<Long, Person> personMap = hz.getMap("personMap");
        personMap.put(1L, new Person(1L, "Peter_1"));
        personMap.put(2L, new Person(2L, "Peter_2"));
        personMap.put(3L, new Person(3L, "Peter_3"));
        personMap.put(4L, new Person(4L, "Peter_4"));
        personMap.put(5L, new Person(5L, "Peter_5"));
        personMap.put(6L, new Person(6L, "Peter_6"));
        personMap.put(7L, new Person(7L, "Peter_7"));

       hz.shutdown();
    }
}
